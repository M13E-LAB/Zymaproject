<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <!-- En-tête produit -->
    <div class="row mb-5">
        <div class="col-md-5 mb-4 mb-md-0">
            <div class="product-image">
                <img src="<?php echo e($productInfo['image_url']); ?>" alt="<?php echo e($productInfo['product_name']); ?>" class="img-fluid">
            </div>
        </div>
        <div class="col-md-7">
            <div class="product-details">
                <h6 class="text-success mb-3">powered by etchelast</h6>
                <h1 class="mb-3"><?php echo e($productInfo['product_name']); ?></h1>
                <p class="text-secondary mb-2"><?php echo e($productInfo['product_quantity']); ?></p>
                <p class="text-muted"><small><?php echo e($productCode); ?></small></p>
                
                <div class="mt-4 mb-4 text-center">
                    <h3 class="text-success mb-3">MEILLEUR PRIX ACTUEL</h3>
                    <h2 class="display-4 fw-bold mb-3"><?php echo e(number_format($stats['min'], 2)); ?>€</h2>
                    <p class="text-secondary">
                        soit <span class="text-success"><?php echo e(number_format($stats['max'] - $stats['min'], 2)); ?>€</span> d'économie possible
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistiques -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="price-stats">
                <div class="price-stat-item">
                    <i class="fas fa-arrow-down"></i>
                    <h4>Prix Min</h4>
                    <h3 class="text-success fw-bold"><?php echo e(number_format($stats['min'], 2)); ?>€</h3>
                </div>
                <div class="price-stat-item">
                    <i class="fas fa-equals"></i>
                    <h4>Prix Moyen</h4>
                    <h3 class="fw-bold"><?php echo e(number_format($stats['avg'], 2)); ?>€</h3>
                </div>
                <div class="price-stat-item">
                    <i class="fas fa-arrow-up"></i>
                    <h4>Prix Max</h4>
                    <h3 class="text-danger fw-bold"><?php echo e(number_format($stats['max'], 2)); ?>€</h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Liste des magasins -->
    <div class="row mb-5">
        <div class="col-12 mb-4 text-center">
            <h2 class="text-success position-relative d-inline-block">
                <span class="position-relative">COMPARAISON DES PRIX</span>
                <div class="position-absolute bg-success" style="height: 2px; width: 50%; bottom: -10px; left: 25%;"></div>
            </h2>
        </div>

        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 mb-4">
            <div class="card <?php echo e($price['price'] == $stats['min'] ? 'border-success' : ''); ?>" 
                 style="border-left-width: <?php echo e($price['price'] == $stats['min'] ? '4px' : '1px'); ?>;">
                <div class="card-body">
                    <div class="row align-items-center">
                        <!-- Infos du magasin -->
                        <div class="col-md-7 mb-3 mb-md-0">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle me-3 d-flex align-items-center justify-content-center" 
                                     style="width: 60px; height: 60px; background: <?php echo e($price['price'] == $stats['min'] ? 'rgba(0, 209, 178, 0.2)' : 'var(--card-bg)'); ?>;">
                                    <i class="fas fa-store <?php echo e($price['price'] == $stats['min'] ? 'text-success' : ''); ?> fa-lg"></i>
                                </div>
                                <div>
                                    <div class="d-flex align-items-center mb-1">
                                        <h4 class="mb-0 me-2"><?php echo e($price['store']); ?></h4>
                                        <?php if($price['price'] == $stats['min']): ?>
                                        <span class="badge bg-success bg-opacity-25 text-success small">
                                            MEILLEUR PRIX
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <p class="text-secondary mb-2 small"><?php echo e($price['address']); ?></p>
                                    
                                    <?php if(isset($price['maps_url'])): ?>
                                    <a href="<?php echo e($price['maps_url']); ?>" target="_blank" 
                                       class="btn btn-sm <?php echo e($price['price'] == $stats['min'] ? 'btn-outline-success' : 'btn-outline-light'); ?>">
                                        <i class="fas fa-map-marker-alt me-1"></i>
                                        Voir sur la carte
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Prix -->
                        <div class="col-md-5 text-md-end text-start">
                            <div class="d-flex align-items-center justify-content-md-end justify-content-start">
                                <h3 class="mb-0 <?php echo e($price['price'] == $stats['min'] ? 'text-success' : ''); ?> fw-bold">
                                    <?php echo e(number_format($price['price'], 2)); ?>€
                                </h3>
                                
                                <?php if($price['price'] == $stats['min']): ?>
                                <i class="fas fa-crown text-success ms-2 fa-sm"></i>
                                <?php endif; ?>
                            </div>
                            
                            <?php if($price['price'] > $stats['min']): ?>
                            <div class="text-danger mt-1">
                                <small>
                                    <i class="fas fa-arrow-up me-1 fa-xs"></i>
                                    +<?php echo e(number_format($price['price'] - $stats['min'], 2)); ?>€ par rapport au min
                                </small>
                            </div>
                            <?php endif; ?>
                            
                            <div class="text-muted mt-2 small">
                                <i class="far fa-calendar-alt me-1"></i>
                                <?php echo e(\Carbon\Carbon::parse($price['date'])->format('d/m/Y')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <!-- Légende & Mentions -->
        <div class="col-12 mt-3">
            <div class="alert alert-info">
                <p class="mb-0 text-center">
                    <i class="fas fa-info-circle me-2"></i>
                    Les prix sont mis à jour régulièrement. Dernière vérification : <?php echo e(date('d/m/Y')); ?>

                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arslane/Documents/Cursor/ZymaMay/Zymaproject/resources/views/products/show.blade.php ENDPATH**/ ?>