<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <a href="<?php echo e(route('social.feed')); ?>" class="btn btn-outline-light mb-3">
                <i class="fas fa-arrow-left me-2"></i> Retour au feed
            </a>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-7 mb-4">
            <div class="card h-100">
                <div class="position-relative">
                    <img src="<?php echo e($post->image); ?>" class="card-img-top" alt="<?php echo e($post->product_name); ?>" style="width: 100%; object-fit: cover;">
                    <span class="badge bg-dark position-absolute top-0 end-0 m-3">
                        <?php switch($post->post_type):
                            case ('price'): ?>
                                <i class="fas fa-tag me-1"></i> Prix
                                <?php break; ?>
                            <?php case ('deal'): ?>
                                <i class="fas fa-percent me-1"></i> Promo
                                <?php break; ?>
                            <?php case ('meal'): ?>
                                <i class="fas fa-utensils me-1"></i> Repas
                                <?php break; ?>
                            <?php case ('review'): ?>
                                <i class="fas fa-star me-1"></i> Avis
                                <?php break; ?>
                        <?php endswitch; ?>
                    </span>
                    
                    <?php if($post->regular_price && $post->getSavingsPercentage() > 0): ?>
                        <span class="badge bg-danger position-absolute top-0 start-0 m-3">
                            -<?php echo e($post->getSavingsPercentage()); ?>%
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-5 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-4">
                        <?php if($post->user->avatar): ?>
                            <img src="<?php echo e($post->user->avatar); ?>" alt="Avatar" class="avatar-small me-2">
                        <?php else: ?>
                            <i class="fas fa-user-circle me-2" style="font-size: 1.5rem;"></i>
                        <?php endif; ?>
                        <div>
                            <div class="fw-bold"><?php echo e($post->user->name); ?></div>
                            <div class="text-secondary small"><?php echo e($post->created_at->format('d/m/Y à H:i')); ?></div>
                        </div>
                    </div>
                    
                    <h3 class="mb-1"><?php echo e($post->product_name); ?></h3>
                    <h5 class="text-secondary mb-4"><?php echo e($post->store_name); ?></h5>
                    
                    <div class="price-stats mb-4">
                        <div class="price-stat-item">
                            <i class="fas fa-tag"></i>
                            <h4 class="mt-2 mb-0 text-success"><?php echo e(number_format($post->price, 2)); ?> €</h4>
                            <div class="text-secondary small">Prix actuel</div>
                        </div>
                        
                        <?php if($post->regular_price): ?>
                            <div class="price-stat-item">
                                <i class="fas fa-euro-sign"></i>
                                <h4 class="mt-2 mb-0 text-secondary text-decoration-line-through"><?php echo e(number_format($post->regular_price, 2)); ?> €</h4>
                                <div class="text-secondary small">Prix habituel</div>
                            </div>
                            
                            <div class="price-stat-item">
                                <i class="fas fa-piggy-bank"></i>
                                <h4 class="mt-2 mb-0 text-success"><?php echo e(number_format($post->getSavingsAttribute(), 2)); ?> €</h4>
                                <div class="text-secondary small">Économie</div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if($post->description): ?>
                        <div class="mb-4">
                            <h5>Description</h5>
                            <p><?php echo e($post->description); ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($post->expires_at): ?>
                        <div class="alert <?php echo e($post->getIsExpiredAttribute() ? 'alert-danger' : 'alert-info'); ?> mb-4">
                            <i class="fas fa-clock me-2"></i>
                            <?php if($post->getIsExpiredAttribute()): ?>
                                <span>Offre expirée depuis le <?php echo e($post->expires_at->format('d/m/Y')); ?></span>
                            <?php else: ?>
                                <span>Offre valable jusqu'au <?php echo e($post->expires_at->format('d/m/Y')); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="d-flex mb-3">
                        <form action="<?php echo e(route('social.like', $post)); ?>" method="POST" class="me-3">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-light">
                                <?php if($post->likes()->where('user_id', auth()->id())->exists()): ?>
                                    <i class="fas fa-heart text-danger me-1"></i>
                                <?php else: ?>
                                    <i class="far fa-heart me-1"></i>
                                <?php endif; ?>
                                <span><?php echo e($post->likes_count); ?></span> J'aime
                            </button>
                        </form>
                        
                        <button type="button" class="btn btn-outline-light" onclick="document.getElementById('comment-form').scrollIntoView();">
                            <i class="far fa-comment me-1"></i>
                            <span><?php echo e($post->comments_count); ?></span> Commenter
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-body">
                    <h4 class="mb-4">Commentaires</h4>
                    
                    <form action="<?php echo e(route('social.comment', $post)); ?>" method="POST" id="comment-form" class="mb-4">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex">
                            <?php if(auth()->user()->avatar): ?>
                                <img src="<?php echo e(auth()->user()->avatar); ?>" alt="Avatar" class="avatar-small me-3 mt-1">
                            <?php else: ?>
                                <i class="fas fa-user-circle me-3 mt-1" style="font-size: 1.5rem;"></i>
                            <?php endif; ?>
                            <div class="flex-grow-1">
                                <textarea class="form-control mb-2" name="content" rows="2" placeholder="Ajouter un commentaire..." required></textarea>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-1"></i> Commenter
                                </button>
                            </div>
                        </div>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </form>
                    
                    <div class="comments-list">
                        <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="d-flex mb-2">
                                        <?php if($comment->user->avatar): ?>
                                            <img src="<?php echo e($comment->user->avatar); ?>" alt="Avatar" class="avatar-small me-2">
                                        <?php else: ?>
                                            <i class="fas fa-user-circle me-2" style="font-size: 1.5rem;"></i>
                                        <?php endif; ?>
                                        <div>
                                            <div class="fw-bold"><?php echo e($comment->user->name); ?></div>
                                            <div class="text-secondary small"><?php echo e($comment->created_at->diffForHumans()); ?></div>
                                        </div>
                                    </div>
                                    
                                    <p class="mb-0"><?php echo e($comment->content); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center p-4">
                                <i class="far fa-comment-dots mb-3" style="font-size: 3rem; color: var(--accent-primary);"></i>
                                <h5>Aucun commentaire pour le moment</h5>
                                <p class="text-secondary">Soyez le premier à commenter cette publication !</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arslane/Documents/Cursor/ZymaMay/Zymaproject/resources/views/social/show.blade.php ENDPATH**/ ?>