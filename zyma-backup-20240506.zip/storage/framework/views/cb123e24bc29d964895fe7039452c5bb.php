<?php $__env->startSection('content'); ?>
    <h1>Product List</h1>
    <table class="table">
        <thead>
            <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->code); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-sm btn-info">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arslane/Documents/Cursor/ZymaMay/Zymaproject/resources/views/products/index.blade.php ENDPATH**/ ?>