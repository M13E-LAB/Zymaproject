<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OpenFoodFacts Price Checker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>OpenFoodFacts Price Checker</h1>
        
        <form action="/" method="POST" class="mb-4">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="product_code" class="form-label">Product Code</label>
                <input type="text" class="form-control" id="product_code" name="product_code" required>
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo e($error); ?></div>
        <?php endif; ?>

        <?php if(isset($prices) && isset($productCode)): ?>
            <h2>Prices for Product Code: <?php echo e($productCode); ?></h2>
            <?php if(count($prices) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Store</th>
                            <th>Price</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($price['store'] ?? 'Unknown'); ?></td>
                                <td><?php echo e($price['price'] ?? 'N/A'); ?></td>
                                <td><?php echo e($price['date'] ?? 'N/A'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No prices found for this product.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH /Users/arslane/Documents/Cursor/ZymaMay/Zymaproject/resources/views/index.blade.php ENDPATH**/ ?>